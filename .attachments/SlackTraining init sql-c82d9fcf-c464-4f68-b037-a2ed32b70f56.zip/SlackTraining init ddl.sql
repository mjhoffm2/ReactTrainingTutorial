USE [SlackTraining]
GO
/****** Object:  Table [dbo].[Channel]    Script Date: 10/12/2018 3:31:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Channel](
	[ChannelId] [bigint] IDENTITY(1,1) NOT NULL,
	[OwnerId] [bigint] NULL,
	[DisplayName] [varchar](200) NOT NULL,
	[Description] [nvarchar](200) NULL,
	[IsPublic] [bit] NOT NULL,
	[CanAnyoneInvite] [bit] NOT NULL,
	[IsGeneral] [bit] NOT NULL,
	[IsActiveDirectMessage] [bit] NOT NULL,
	[IsSoftDeleted] [bit] NOT NULL,
 CONSTRAINT [PK_Channel] PRIMARY KEY CLUSTERED 
(
	[ChannelId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Message]    Script Date: 10/12/2018 3:31:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Message](
	[MessageId] [bigint] IDENTITY(1,1) NOT NULL,
	[ChannelId] [bigint] NOT NULL,
	[UserId] [bigint] NOT NULL,
	[Timestamp] [datetime] NOT NULL,
	[Message] [nvarchar](max) NOT NULL,
	[IsEdited] [bit] NOT NULL,
 CONSTRAINT [PK_Message] PRIMARY KEY CLUSTERED 
(
	[MessageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 10/12/2018 3:31:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[UserId] [bigint] IDENTITY(1,1) NOT NULL,
	[Username] [varchar](200) NOT NULL,
	[DisplayName] [varchar](200) NULL,
	[Email] [varchar](200) NULL,
	[Status] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
	[IsSoftDeleted] [bit] NOT NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserChannel]    Script Date: 10/12/2018 3:31:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserChannel](
	[UserChannelId] [bigint] IDENTITY(1,1) NOT NULL,
	[UserId] [bigint] NOT NULL,
	[ChannelId] [bigint] NOT NULL,
	[JoinDate] [datetime] NOT NULL,
 CONSTRAINT [PK_UserChannel] PRIMARY KEY CLUSTERED 
(
	[UserChannelId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Channel_DisplayName]    Script Date: 10/12/2018 3:31:22 PM ******/
CREATE NONCLUSTERED INDEX [IX_Channel_DisplayName] ON [dbo].[Channel]
(
	[DisplayName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Message_ChannelId_Timestamp]    Script Date: 10/12/2018 3:31:22 PM ******/
CREATE NONCLUSTERED INDEX [IX_Message_ChannelId_Timestamp] ON [dbo].[Message]
(
	[ChannelId] ASC,
	[Timestamp] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_User_Username]    Script Date: 10/12/2018 3:31:22 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_User_Username] ON [dbo].[User]
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_UserChannel_ChannelId_UserId]    Script Date: 10/12/2018 3:31:22 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_UserChannel_ChannelId_UserId] ON [dbo].[UserChannel]
(
	[ChannelId] ASC,
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_UserChannel_UserId_ChannelId]    Script Date: 10/12/2018 3:31:22 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_UserChannel_UserId_ChannelId] ON [dbo].[UserChannel]
(
	[UserId] ASC,
	[ChannelId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Channel]  WITH CHECK ADD  CONSTRAINT [FK_Channel_User] FOREIGN KEY([OwnerId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[Channel] CHECK CONSTRAINT [FK_Channel_User]
GO
ALTER TABLE [dbo].[Message]  WITH CHECK ADD  CONSTRAINT [FK_Message_Channel] FOREIGN KEY([ChannelId])
REFERENCES [dbo].[Channel] ([ChannelId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Message] CHECK CONSTRAINT [FK_Message_Channel]
GO
ALTER TABLE [dbo].[Message]  WITH CHECK ADD  CONSTRAINT [FK_Message_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[Message] CHECK CONSTRAINT [FK_Message_User]
GO
ALTER TABLE [dbo].[UserChannel]  WITH CHECK ADD  CONSTRAINT [FK_UserChannel_Channel] FOREIGN KEY([ChannelId])
REFERENCES [dbo].[Channel] ([ChannelId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserChannel] CHECK CONSTRAINT [FK_UserChannel_Channel]
GO
ALTER TABLE [dbo].[UserChannel]  WITH CHECK ADD  CONSTRAINT [FK_UserChannel_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[UserChannel] CHECK CONSTRAINT [FK_UserChannel_User]
GO